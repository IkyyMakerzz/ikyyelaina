import fetch from 'node-fetch'
import fs from 'fs'
import { sticker } from '../lib/sticker.js'
let handler = async (m, { conn, usedPrefix, text, args, command }) => {
let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let pp = await conn.profilePictureUrl(who).catch(_ => hwaifu.getRandom())
let name = await conn.getName(who)

let delay = time => new Promise(res => setTimeout(res, time))

await conn.reply(m.chat, `ʜɪɪ ${name} ᴛʜɪs ɪs ᴏᴡɴᴇʀ ɪᴋʏʏᴋᴀᴢᴇ (ʘᴗʘ✿'`, fpayment)
if (command == 'owner') {
  let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:;${wm};;;\nFN:${wm}\nORG:${wm}\nTITLE:\nitem1.TEL;waid=${nomorown}:${nomorown}\nitem1.X-ABLabel:AbiDev\nX-WA-BIZ-DESCRIPTION:ᴛʜᴇ ᴏᴡɴᴇʀ\nX-WA-BIZ-NAME:${wm}\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: wm, contacts: [{ vcard }] }},)
  }
   let stiker = await sticker(null, global.API(`https://telegra.ph/file/1d1f204fa0b46d0fd3cbc.jpg`), global.packname, global.author)
    await delay(2000)
    if (stiker) return await conn.sendFile(m.chat, stiker, 'sticker.webp', '', m)
  }
handler.help = ['owner', 'creator']
handler.tags = ['info']

handler.command = /^(owner|creator)$/i

export default handler